import random
from main import *
import pytest



# def test_datafunc():
#      assert data({'book_allow','movie_deny','python_allow','sleep_deny','*_allow'},'sleep') == False
#
#
#
# def test_automaticdata():
#      test_inputs = {'book':True,'C#':True,'skateboard':True,'python':True,'movie':False}
#      for i in test_inputs.keys():
#           print(i , '-> ',test_inputs[i])
#           assert data({'book_allow','movie_deny','python_allow','sleep_deny','*_allow'},i) == test_inputs[i]
#
#
#
# def test_errorDAT():
#      with pytest.raises(TypeError):
#           assert data({'book_allow','movie_deny','python_allow','sleep_deny','*_allow'},2)
#
# def test_is_ip():
#      assert is_ip('10.13.236.65') == True
#      assert is_ip('010.015.236.1') == False
#      assert is_ip('hdjsankjdsadkbasdkj') == False
# def rand(rand_ip,result):
#      assert is_ip(rand_ip) == result
#
# def do_rand():
#      for i in range(100):
#           print(i)
#           a = random.randint(-3,260)
#           b = random.randint(-3,260)
#           c = random.randint(-3,260)
#           d = random.randint(-3,260)
#           ip = f'{a}.{b}.{c}.{d}'
#           result = False
#           if a >= 0 and a <= 255 and b >=0 and b <= 255 and c >= 0 and c <= 255 and d >= 0 and d <= 255:
#                result= True
#           rand(ip, result)
#
#
#
#
#
# do_rand()
#
# def test_palind():
#      assert palind('ded') == True
#      assert palind('dhdgf') == False
#      with pytest.raises(ValueError):
#           assert palind('123')
#
#
# def test_f():
#      assert f(4, 8) == 12
#      with pytest.raises(TypeError):
#           assert f('sad', 'jkns')
#
#
# def test_z():
#      assert z(3) == 27
#      assert z(2,10) == 2048
#      with pytest.raises(TypeError):
#           assert f('sad', )
#
# def test_split_data():
#      assert split_data('2024-10-12') == ('12','10','2024')
#      with pytest.raises(ValueError):
#           assert split_data('10000-19-32')
#
#
#
# def test_divide_list():
#      assert divide_list([1,2,3,4,5,6]) == 6/15
#      assert divide_list([5,2,3,1,2,3]) == 10/6
#      with pytest.raises(ValueError):
#           assert divide_list(['23',2,3,5,5])

# def test_to_hex():
#      assert to_hex(110, 161, 120) == "#6EA178"
#      assert to_hex(15, 165,139) == "#0FA58B"
#      assert to_hex(145, 154, 105) == "#919A69"

# def test_combain():
#      assert combain({1:'sa'},{3:'ksdn'}) == {1: 'sa', 3: 'ksdn'}
#      with pytest.raises(ValueError):
#           assert combain(1,2)

def test_sum_dict():
    assert sum_dict({1: {1: 11,2: 12,3: 13,},}) == 36
    with pytest.raises(ValueError):
        assert sum_dict({1:10,2:11,3:'12'})