# DATA ({book_allow,movies_deny},book), TRUE
# def data(data:set, target:str):
#      if type(target) != str:
#           raise TypeError('Ошибка!')
#      for i in data:
#           item_data = i.split('_')
#           if target == item_data[0]:
#                if item_data[1] == 'allow':
#                     return True
#                else:
#                     return False
#      for j in data:
#           item_data = j.split('_')
#           if '*' == item_data[0]:
#                if item_data[1] == 'deny':
#                     return False
#                else:
#                     return True
#      else:
#           return False




# def is_ip(ip):
#     lubya = ip.split(".")
#     x = [False, False, False, False]
#     count = 0
#     if len(lubya) == 4:
#         for i in lubya:
#             if i[0] == '0' and len(i) > 1:
#                 return False
#             if i.isdigit():
#                 if int(i) <= 255 and int(i) >= 0:
#                     x[count] = True
#                     count += 1
#                 else:
#                     return False
#         if False in x:
#             return False
#         else:
#             return True
#     else:
#         return False
# try:
#     count = int(input())
#     print(count)
#     divisor = int(input())
#     print(count//divisor)
#     if divisor == 225:
#         raise TypeError('нельзя')
# except ValueError:
#     print('число')
# except ZeroDivisionError as ex:
#     print(ex)


#
# def palind(sent: str):
#     for i in sent:
#         if i.isdigit():
#             raise ValueError('тут число')
#     if sent.lower() == sent.lower()[::-1]:
#         return True
#     else:
#         return False



# def f(a: int, b: int):
#     if type(a) == int and type(b) == int:
#         return a + b
#     else:
#         raise TypeError("Вы ввели не числа")



# def z(a,pow=2):
#     if type(a) != int:
#         raise  TypeError('Вы ввели не числа')
#     out = a
#     for i in range(pow):
#         out *= a
#     return out
#
# def split_data(data):
#     spec = ['.',',','+','!']
#     data = data.split('-')[::-1]
#     if int(data[0]) > 31 or int(data[0]) < 0:
#         raise ValueError('не может быть больше 31 дня')
#     if int(data[1]) > 12 or int(data[0]) < 0:
#         raise ValueError('не может быть больше 12 месяцев')
#     if int(data[0]) < 0:
#         raise ValueError('не может быть меньше 1 года')
#     return tuple(data)


# def word_summ(words):
#     count = 0
#     if words:
#         for i in words:
#             if type(i) == str:
#                 if i.isdigit():
#                     count += int(i)
#     return count

# def divide_list(lst:list):
#     for i in lst:
#         if type(i) == str:
#             raise ValueError('не число')
#     middle = len(lst) // 2
#     first_half = lst[:middle]
#     second_half = lst[middle:]
#     return sum(first_half) / sum(second_half)

# def to_hex(r,g,b):
#     lst ='#'
#     hex = {
#         0: '0',
#         1: '1',
#         2: '2',
#         3: '3',
#         4: '4',
#         5: '5',
#         6: '6',
#         7: '7',
#         8: '8',
#         9: '9',
#         10: 'A',
#         11: 'B',
#         12: 'C',
#         13: 'D',
#         14: 'E',
#         15: 'F'
#     }
#     for i in (r,g,b):
#         temp1 = i//16
#         temp2 = i%16
#         lst += hex[temp1] + hex[temp2]
#     return lst
# print(to_hex(25,25,25))

# def combain(a, b):
#     if type(a) != dict or type(b) != dict:
#         raise ValueError("error")
#     combine = a.copy()
#     combine.update(b)
#     return combine
#
# print(combain({1:'sa'},{3:'ksdn'}))


def sum_dict(dict:dict):
    summ = 0
    for i in dict.values():
        for j in i.values():
            if type(j) == int:
                summ += j
            else:
                raise ValueError('должны быть числа')
    return summ
print(sum_dict({1: {1: 11,2: 12,3: 13,},
                2: {1: 21,2: 22,3: 23,},
                3: {1: 24,2: 25,3: 26,},
                }))