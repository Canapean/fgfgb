# def hello():
#     print('Hello World!')

# def fib(n):
#     a = b = 1
#     for i in range(n-2):
#         a,b = b,a+b
#     return b
# def su(a,b):
#     return a + b
# def df(a,b):
#     return a - b
# def mul(a,b):
#     return a * b
# def di(a,b):
#     if b == 0:
#         return 'на 0 делить нельзя'
#     else:
#         return a / b
# def my_all():
#     hello()
#     print(fib(10))

def de(number):
    lst = []
    for i in range(1,number+1):
        if number%i == 0:
            lst.append(i)
    return lst

def tree_args(var1=None,var2=None,var3=None):
    return f"Переданы аргументы: {'var1 = ' + str(var1) + ', ' if var1 else ''}{'var2 = ' + str(var2) + ', ' if var2 else ''}{'var3 = ' + str(var3) if var3 else ''}"

def pal(word):
    text = ''
    for i in word:
        if i != ' ' and i != ',' and i != '!':
            text = text + i
    text = text.lower()
    return True if text == text[::-1] else False

def mat(n,m):
    pass

# if __name__ == "__main__":
#     my_all()