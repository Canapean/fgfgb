import mymodule
# a = int(input('введите первое число: '))
# b = int(input('введите второе число: '))
# c = input('выберите действие [+][-][*][/]: ')

# a = int(input('введите число: '))
print(mymodule.de(16))

print(mymodule.tree_args(1,var3=3))

print(mymodule.pal('А роза упала, на лапу Азора!'))

