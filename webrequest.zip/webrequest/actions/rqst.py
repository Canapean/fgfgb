import requests
from settings.config import USERS_URL

def request_method_get(target_url: str, UID: str = "", data: str = ""):
    response = requests.get(
        url=target_url + '/' +str(UID)
    )
    if response.status_code == 200:
        return response.json()
    else:
        pass
result = request_method_get(target_url=USERS_URL, UID = 1)

# with open('index.html', 'w', encoding='utf-8') as html:
#     html.write(result)


def create_secret(lgt: int = 8) -> str:
    import random
    from string import printable
    secret = ''
    while len(secret) != lgt:
        secret += random.choice(printable)
    return secret