from actions.rqst import request_method_get,USERS_URL,create_secret


# l = input('>>')
# p = input('>>')

users = request_method_get(target_url=USERS_URL)
usernames = []
for user in users:
    for key in user.keys():
        if key == 'username':
            usernames.append(user[key])

print(usernames)

sign_in_data = {}

for name in usernames:
    sign_in_data.update({name:create_secret(16)})

print(sign_in_data)


