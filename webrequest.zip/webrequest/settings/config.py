BASE_URL_JSN ="https://jsonplaceholder.typicode.com/"
USERS_URL = BASE_URL_JSN + 'users'
HTTP_BIN_URL = "https://httpbin.org/"